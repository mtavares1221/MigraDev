exports.configs = {
  api_usuario: {
    http_port: 3001,
  },
};
